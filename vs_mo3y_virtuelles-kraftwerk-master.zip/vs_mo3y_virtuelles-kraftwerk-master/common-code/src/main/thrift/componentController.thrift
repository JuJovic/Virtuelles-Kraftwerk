namespace java src.main.java.thrift

service ComponentController {
  bool setPower(1: double power),
}